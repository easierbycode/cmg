﻿console.log('monkey blaster');

